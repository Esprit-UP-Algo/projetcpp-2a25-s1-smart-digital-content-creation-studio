#include "gemploye.h"
#include "ui_gemploye.h"
#include <QRegularExpression>
#include <QRegularExpressionValidator>
#include <QMessageBox>
#include <QPixmap>

Gemploye::Gemploye(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Gemploye)
    , selectedReference("")
{
    ui->setupUi(this);

    // Logo
    QPixmap logo("C:/Users/LOQ/Documents/Gemploye/images/logo.png");
    ui->label_7->setPixmap(logo.scaled(ui->label_7->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));

    // Validators
    QRegularExpression regexChiffres("^[0-9]+$");
    ui->lineEdit_11->setValidator(new QRegularExpressionValidator(regexChiffres, this)); // REFERENCE

    QRegularExpression regexLettres("^[a-zA-ZÀ-ÿ ]{0,20}$");
    ui->lineEdit_9->setValidator(new QRegularExpressionValidator(regexLettres, this));   // TYPE_APPAREIL
    ui->lineEdit_9->setMaxLength(20);
    ui->lineEdit_10->setValidator(new QRegularExpressionValidator(regexLettres, this));  // MARQUE
    ui->lineEdit_10->setMaxLength(20);

    // TableWidget - 4 colonnes
    ui->tableWidget_6->setColumnCount(4);
    ui->tableWidget_6->setHorizontalHeaderLabels({"Type Appareil","Référence","Marque","Disponibilité"});
    ui->tableWidget_6->horizontalHeader()->setStretchLastSection(true);

    // Affichage initial
    Mtmp.afficher(ui->tableWidget_6);

    // Connect signal
    connect(ui->tableWidget_6, &QTableWidget::cellClicked, this, &Gemploye::on_tableWidget_6_cellClicked);
}

Gemploye::~Gemploye()
{
    delete ui;
}

// Navigation
void Gemploye::on_Employ_clicked()   { ui->stackedWidget->setCurrentIndex(0); }
void Gemploye::on_Employ_4_clicked() { ui->stackedWidget->setCurrentIndex(1); }
void Gemploye::on_Employ_2_clicked() { ui->stackedWidget->setCurrentIndex(2); }
void Gemploye::on_Employ_6_clicked() { ui->stackedWidget->setCurrentIndex(3); }
void Gemploye::on_Employ_3_clicked() { ui->stackedWidget->setCurrentIndex(4); }
void Gemploye::on_Employ_5_clicked() { ui->stackedWidget->setCurrentIndex(5); }

// Ajouter un matériel
void Gemploye::on_pushButton_8_clicked()
{
    if(ui->lineEdit_9->text().isEmpty() ||
        ui->lineEdit_10->text().isEmpty() ||
        ui->lineEdit_11->text().isEmpty())
    {
        QMessageBox::warning(this, "Champ vide", "Veuillez remplir tous les champs !");
        return;
    }

    QString type = ui->lineEdit_9->text();          // TYPE_APPAREIL
    QString ref = ui->lineEdit_11->text();          // REFERENCE
    QString marque = ui->lineEdit_10->text();       // MARQUE
    QString dispo = ui->comboBox_10->currentText(); // DISPONIBILITE

    if(type.length() > 20 || marque.length() > 20)
    {
        QMessageBox::warning(this, "Erreur", "Type ou marque trop long (max 20 caractères) !");
        return;
    }

    Materiel M(type, ref, marque, dispo);

    if(M.ajouter())
    {
        QMessageBox::information(this, "Succès", "Matériel ajouté !");
        ui->lineEdit_9->clear();
        ui->lineEdit_10->clear();
        ui->lineEdit_11->clear();
        ui->comboBox_10->setCurrentIndex(0);

        Mtmp.afficher(ui->tableWidget_6);
    }
    else
        QMessageBox::critical(this, "Erreur", "Échec de l'ajout !");
}

// Sélection d'une ligne
void Gemploye::on_tableWidget_6_cellClicked(int row, int column)
{
    Q_UNUSED(column);

    selectedReference = ui->tableWidget_6->item(row, 1)->text(); // Colonne 1 = REFERENCE

    ui->lineEdit_9->setText(ui->tableWidget_6->item(row, 0)->text());  // TYPE_APPAREIL
    ui->lineEdit_11->setText(ui->tableWidget_6->item(row, 1)->text()); // REFERENCE
    ui->lineEdit_10->setText(ui->tableWidget_6->item(row, 2)->text()); // MARQUE

    int indexCombo = ui->comboBox_10->findText(ui->tableWidget_6->item(row, 3)->text());
    if(indexCombo != -1)
        ui->comboBox_10->setCurrentIndex(indexCombo);
}

// Modifier un matériel
void Gemploye::on_pushButton_11_clicked()
{
    if(selectedReference.isEmpty())
    {
        QMessageBox::warning(this, "Erreur", "Veuillez sélectionner un matériel dans le tableau !");
        return;
    }

    QString type = ui->lineEdit_9->text();
    QString ref = ui->lineEdit_11->text();
    QString marque = ui->lineEdit_10->text();
    QString dispo = ui->comboBox_10->currentText();

    if(type.isEmpty() || marque.isEmpty() || ref.isEmpty())
    {
        QMessageBox::warning(this, "Erreur", "Veuillez remplir tous les champs !");
        return;
    }

    Materiel M(type, ref, marque, dispo);

    if(M.modifier(selectedReference))
    {
        QMessageBox::information(this, "Succès", "Matériel modifié !");
        selectedReference = ref; // Mise à jour si la référence a changé
        Mtmp.afficher(ui->tableWidget_6);
    }
    else
        QMessageBox::critical(this, "Erreur", "Échec de la modification !");
}

// Supprimer un matériel
void Gemploye::on_pushButton_9_clicked()
{
    if(selectedReference.isEmpty())
    {
        QMessageBox::warning(this, "Erreur", "Veuillez sélectionner un matériel à supprimer !");
        return;
    }

    int ret = QMessageBox::question(this, "Supprimer",
                                    "Voulez-vous vraiment supprimer ce matériel ?",
                                    QMessageBox::Yes | QMessageBox::No);

    if(ret == QMessageBox::Yes)
    {
        Materiel M;
        if(M.supprimer(selectedReference))
        {
            QMessageBox::information(this, "Succès", "Matériel supprimé !");
            selectedReference = "";
            Mtmp.afficher(ui->tableWidget_6);

            ui->lineEdit_9->clear();
            ui->lineEdit_10->clear();
            ui->lineEdit_11->clear();
            ui->comboBox_10->setCurrentIndex(0);
        }
        else
            QMessageBox::critical(this, "Erreur", "Échec de la suppression !");
    }
}
