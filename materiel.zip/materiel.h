#ifndef MATERIEL_H
#define MATERIEL_H
#include <QString>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QTableWidget>

class Materiel
{
private:
    QString type_appareil;
    QString reference;
    QString disponibilite;
    QString marque;

public:
    Materiel();
    Materiel(QString type, QString ref, QString marque, QString dispo);

    bool ajouter();
    bool afficher(QTableWidget *table);
    bool modifier(QString ref);
    bool supprimer(QString ref);
};
#endif // MATERIEL_H
