#ifndef GEMPLOYE_H
#define GEMPLOYE_H
#include <QMainWindow>
#include <QMessageBox>
#include "materiel.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Gemploye;
}
QT_END_NAMESPACE

class Gemploye : public QMainWindow
{
    Q_OBJECT
public:
    Gemploye(QWidget *parent = nullptr);
    ~Gemploye();

private slots:
    void on_Employ_clicked();
    void on_Employ_4_clicked();
    void on_Employ_2_clicked();
    void on_Employ_6_clicked();
    void on_Employ_3_clicked();
    void on_Employ_5_clicked();
    void on_pushButton_8_clicked();   // Ajouter
    void on_pushButton_11_clicked();  // Modifier
    void on_pushButton_9_clicked();   // Supprimer
    void on_tableWidget_6_cellClicked(int row, int column);

private:
    Ui::Gemploye *ui;
    Materiel Mtmp;
    QString selectedReference; // REFERENCE du matériel sélectionné
};
#endif // GEMPLOYE_H
