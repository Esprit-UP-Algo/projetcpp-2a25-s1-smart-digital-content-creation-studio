#include "materiel.h"

// Constructeurs
Materiel::Materiel()
{
    type_appareil = "";
    reference = "";
    marque = "";
    disponibilite = "";
}

Materiel::Materiel(QString type, QString ref, QString m, QString dispo)
{
    type_appareil = type;
    reference = ref;
    marque = m;
    disponibilite = dispo;
}

// Ajouter un matériel
bool Materiel::ajouter()
{
    QSqlQuery query;
    query.prepare("INSERT INTO MATERIEL (TYPE_APPAREIL, REFERENCE, MARQUE, DISPONIBILITE) "
                  "VALUES (:type, :ref, :marque, :dispo)");
    query.bindValue(":type", type_appareil);
    query.bindValue(":ref", reference);
    query.bindValue(":marque", marque);
    query.bindValue(":dispo", disponibilite);

    if(query.exec())
    {
        qDebug() << "SUCCES: Materiel ajoute!";
        return true;
    }
    else
    {
        qDebug() << "ERREUR SQL:" << query.lastError().text();
        return false;
    }
}

// Afficher tous les matériels
bool Materiel::afficher(QTableWidget *table)
{
    QSqlQuery query("SELECT TYPE_APPAREIL, REFERENCE, MARQUE, DISPONIBILITE FROM MATERIEL");
    table->setRowCount(0);
    int row = 0;

    while(query.next())
    {
        table->insertRow(row);
        table->setItem(row, 0, new QTableWidgetItem(query.value(0).toString())); // TYPE_APPAREIL
        table->setItem(row, 1, new QTableWidgetItem(query.value(1).toString())); // REFERENCE
        table->setItem(row, 2, new QTableWidgetItem(query.value(2).toString())); // MARQUE
        table->setItem(row, 3, new QTableWidgetItem(query.value(3).toString())); // DISPONIBILITE
        row++;
    }
    return true;
}

// Modifier un matériel (basé sur REFERENCE)
bool Materiel::modifier(QString ref)
{
    QSqlQuery query;
    query.prepare("UPDATE MATERIEL SET TYPE_APPAREIL=:type, MARQUE=:marque, DISPONIBILITE=:dispo WHERE REFERENCE=:ref");
    query.bindValue(":type", type_appareil);
    query.bindValue(":marque", marque);
    query.bindValue(":dispo", disponibilite);
    query.bindValue(":ref", ref);

    if(query.exec())
    {
        qDebug() << "SUCCES: Materiel modifie!";
        return true;
    }
    else
    {
        qDebug() << "ERREUR SQL:" << query.lastError().text();
        return false;
    }
}

// Supprimer un matériel (basé sur REFERENCE)
bool Materiel::supprimer(QString ref)
{
    QSqlQuery query;
    query.prepare("DELETE FROM MATERIEL WHERE REFERENCE=:ref");
    query.bindValue(":ref", ref);

    if(query.exec())
    {
        qDebug() << "SUCCES: Materiel supprime!";
        return true;
    }
    else
    {
        qDebug() << "ERREUR SQL:" << query.lastError().text();
        return false;
    }
}
